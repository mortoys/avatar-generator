(window["webpackJsonp"]=window["webpackJsonp"]||[]).push([["chunk-2d237780"],{faf5:function(c,n,p){c.exports=p.p+"img/31700.ccc5920c.png"}}]);
//# sourceMappingURL=chunk-2d237780.c6819251.js.map