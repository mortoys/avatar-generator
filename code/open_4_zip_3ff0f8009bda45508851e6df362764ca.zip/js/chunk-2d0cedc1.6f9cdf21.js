(window["webpackJsonp"]=window["webpackJsonp"]||[]).push([["chunk-2d0cedc1"],{"60f7":function(n,p,c){n.exports=c.p+"img/120780.9f4bb176.png"}}]);
//# sourceMappingURL=chunk-2d0cedc1.6f9cdf21.js.map