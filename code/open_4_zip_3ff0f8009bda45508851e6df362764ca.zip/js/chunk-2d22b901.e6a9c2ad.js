(window["webpackJsonp"]=window["webpackJsonp"]||[]).push([["chunk-2d22b901"],{f001:function(n,p,o){n.exports=o.p+"img/160102.cb758ed5.png"}}]);
//# sourceMappingURL=chunk-2d22b901.e6a9c2ad.js.map