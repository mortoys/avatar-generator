(window["webpackJsonp"]=window["webpackJsonp"]||[]).push([["chunk-2d20780f"],{a18a:function(n,p,c){n.exports=c.p+"img/10220.cffac17d.png"}}]);
//# sourceMappingURL=chunk-2d20780f.437a9db5.js.map