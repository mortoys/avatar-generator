(window["webpackJsonp"]=window["webpackJsonp"]||[]).push([["chunk-2d0af80f"],{"0f36":function(n,p,c){n.exports=c.p+"img/60155.6fcdced5.png"}}]);
//# sourceMappingURL=chunk-2d0af80f.392a42f9.js.map